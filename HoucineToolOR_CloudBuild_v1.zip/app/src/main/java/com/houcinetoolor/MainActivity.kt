package com.houcinetoolor

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var usbManager: UsbManager
    private lateinit var statusText: TextView
    private lateinit var detailsText: TextView

    private val permissionAction = "com.houcinetoolor.USB_PERMISSION"

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                permissionAction -> {
                    val device = usbDeviceFrom(intent)
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    if (device != null && granted) {
                        showDevice(device, "تم منح إذن USB")
                    } else {
                        statusText.text = "لم يتم منح إذن USB."
                    }
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> refreshDevices()
                UsbManager.ACTION_USB_DEVICE_DETACHED -> refreshDevices()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            setBackgroundColor(0xFF101216.toInt())
        }

        val title = TextView(this).apply {
            text = "HOUCINE TOOL OR"
            textSize = 26f
            setTextColor(0xFFFFC857.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "ANDROID USB DIAGNOSTIC · V1.0"
            textSize = 12f
            setTextColor(0xFFB8C0CC.toInt())
            gravity = Gravity.CENTER
        }
        statusText = TextView(this).apply {
            text = "جاهز لفحص اتصال USB OTG"
            textSize = 17f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 40, 0, 20)
        }
        detailsText = TextView(this).apply {
            text = "لا يوجد جهاز مفحوص بعد."
            textSize = 14f
            setTextColor(0xFFD6DCE5.toInt())
        }
        val scanButton = Button(this).apply {
            text = "فحص الأجهزة المتصلة"
            setOnClickListener { refreshDevices() }
        }
        val note = TextView(this).apply {
            text = "\nملاحظة: هذه النسخة تكشف أجهزة USB التي يسمح Android برؤيتها. قراءة بيانات الهاتف الآخر تتطلب دعماً من الهاتف المتصل وإذناً مناسباً؛ ولا يمكنها فك قفل الشاشة أو تجاوز التشفير."
            textSize = 12f
            setTextColor(0xFF9AA4B2.toInt())
        }

        layout.addView(title, matchWrap())
        layout.addView(subtitle, matchWrap())
        layout.addView(statusText, matchWrap())
        layout.addView(scanButton, matchWrap())
        layout.addView(detailsText, matchWrap())
        layout.addView(note, matchWrap())
        setContentView(ScrollView(this).apply { addView(layout) })

        val filter = IntentFilter().apply {
            addAction(permissionAction)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(usbReceiver, filter)
        }

        refreshDevices()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun refreshDevices() {
        val devices = usbManager.deviceList.values.toList()
        if (devices.isEmpty()) {
            statusText.text = "لم يتم العثور على جهاز USB."
            detailsText.text = "تحقق من كابل OTG، ومن أن الهاتف الآخر في وضع USB مناسب."
            return
        }

        statusText.text = "تم العثور على ${devices.size} جهاز USB."
        detailsText.text = devices.joinToString("\n\n") { device ->
            "USB device: ${device.deviceName}\nVID: ${device.vendorId} · PID: ${device.productId}\nClass: ${device.deviceClass}\nInterfaces: ${device.interfaceCount}"
        }

        devices.forEach { device ->
            if (!usbManager.hasPermission(device)) requestUsbPermission(device)
            else showDevice(device, "الجهاز متصل والإذن متاح")
        }
    }

    private fun requestUsbPermission(device: UsbDevice) {
        val intent = Intent(permissionAction).setPackage(packageName)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val permissionIntent = PendingIntent.getBroadcast(this, device.deviceId, intent, flags)
        usbManager.requestPermission(device, permissionIntent)
        statusText.text = "بانتظار موافقتك على إذن USB..."
    }

    private fun showDevice(device: UsbDevice, heading: String) {
        statusText.text = heading
        detailsText.text =
            "اسم الجهاز: ${device.deviceName}\n" +
            "Vendor ID: ${device.vendorId}\n" +
            "Product ID: ${device.productId}\n" +
            "USB class: ${device.deviceClass}\n" +
            "عدد الواجهات: ${device.interfaceCount}\n\n" +
            "هذه معلومات USB أولية فقط، وليست تشخيصاً نهائياً لعطل الهاتف."
    }

    @Suppress("DEPRECATION")
    private fun usbDeviceFrom(intent: Intent): UsbDevice? =
        if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        } else {
            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
        }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(usbReceiver) } catch (_: Exception) {}
    }
}
